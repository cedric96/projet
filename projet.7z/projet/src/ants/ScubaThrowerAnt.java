package ants;

public class ScubaThrowerAnt extends ThrowerAnt{
	
	// Fourmi qui est identique a ThrowerAnt mais qui resiste a l'eau
	
	public ScubaThrowerAnt() {
		super();
		foodCost=5;
		watersafe=true;
		this.name="Scuba";
	}
	
}
