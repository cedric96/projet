package core;

//Une abeille qui tape tr�s fort mais qui meurt tr�s vite.

public class GlassCanon extends Bee {

	public GlassCanon(int armor) {
		super(1);
		this.setDamage(4);
		
	}

}
