package core;

public interface Damaging {
	
	public int getDamage();
	
	public void setDamage(int nbre);

}
