package core;


public interface Undeletable {

	
	
}
