package core;
import core.Place;

public class QueenPlace extends Place {
	public Place place_reine;

	
	public QueenPlace(String name) {
		super(name);
	}
	
}
